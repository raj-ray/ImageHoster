package ImageHoster.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="comments")
public class Comment {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(columnDefinition = "text")
    private String text;

    @Column(name = "createdDate")
    private LocalDate createdDate;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_comment")
    private User user;

    @OneToMany(fetch = FetchType.LAZY,mappedBy = "comments")
    private List<Comment> comments;


    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "image_comment")
    private List<Image> images;
    private Comment comment;
    private List<Comment> imageComments;
    private Date date;


    public Comment() {
    }

    public Comment(String commentText){
        this.text = commentText;
        this.user = user;
    }

    public Integer getId(){
        return id;
    }

    public void setId(Integer id){
        this.id = id;
    }

    public String getText(){
        return text;
    }

    public void setText(String text){
        this.text = text;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setImages(List<Image> images){
        this.images = images;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void add(Comment comment) {
        this.comment = comment;
    }

    public void setComments(List<Comment> imageComments) {
        this.imageComments = imageComments;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
