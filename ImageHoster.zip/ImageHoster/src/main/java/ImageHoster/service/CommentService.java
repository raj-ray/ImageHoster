package ImageHoster.service;

import ImageHoster.model.Comment;
import ImageHoster.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    public Comment getCommentByImage(String text){
        return commentRepository.findComment(text);
    }

    public Comment createComment(Comment comment){
        return commentRepository.createComment(comment);
    }

    public Comment deleteComment(Comment commentText){
        return commentRepository.deleteComment(commentText);
    }
}
