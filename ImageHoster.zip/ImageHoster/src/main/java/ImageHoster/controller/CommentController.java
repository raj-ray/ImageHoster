package ImageHoster.controller;

import ImageHoster.model.Comment;
import ImageHoster.model.Image;
import ImageHoster.service.ImageService;
import ImageHoster.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

@Controller
public class CommentController {

    @Autowired
    private ImageService imageService;

    @Autowired
    private UserService userService;
    private CommentController commentService;

    @RequestMapping("/comments/upload")
    public String newComment() {
        return "comments/upload";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/images/{imageId}/{imageTitle}/comments")
    public String createComment(@RequestParam("file") MultipartFile file, Image newImage, HttpSession session, String comments, String newComment) throws IOException {

        String commentText= findOrCreateComment(comments);
        newImage.setComments(commentText);
        newImage.setDate(new Date());
        commentService.uploadComment(newComment);
        return "/comments/comment";
    }

    private void uploadComment(String newComment) {
    }

    private String findOrCreateComment(String commentText) {
        StringTokenizer st = new StringTokenizer(commentText, " , ");

        return commentText ;

    }
}
    

